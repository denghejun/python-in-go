from distutils.core import setup

setup(
    name='foo',
    version='1.0.0',
    py_modules=['foo'],
    author='Hejun Deng',
    author_email='hejun_deng@mckinsey.com',
    url='https://www.github.com',
    description='AbTesting based on Bayesian',
)
