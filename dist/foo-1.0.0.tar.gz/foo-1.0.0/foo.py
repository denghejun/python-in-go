def hello(name):
    d = dict();
    d['name'] = "Hi, " + name
    d['age'] = 50
    return d
